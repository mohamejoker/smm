
import React from 'react';
import ContentManager from '@/components/Admin/ContentManager';

const ContentPage = () => {
  return <ContentManager />;
};

export default ContentPage;
