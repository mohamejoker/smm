
import React from 'react';
import ThemeControlPanel from '@/components/Admin/ThemeControlPanel';

const ThemeControlPage = () => <ThemeControlPanel />;

export default ThemeControlPage;
