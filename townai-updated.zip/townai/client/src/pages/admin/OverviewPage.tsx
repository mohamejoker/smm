
import React from 'react';
import AdminDashboardPage from './AdminDashboardPage';

const OverviewPage = () => {
  return <AdminDashboardPage />;
};

export default OverviewPage;
