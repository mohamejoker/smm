
import React from 'react';
import RoleManagement from '@/components/Admin/RoleManagement';

const RolesPage = () => <RoleManagement />;

export default RolesPage;
