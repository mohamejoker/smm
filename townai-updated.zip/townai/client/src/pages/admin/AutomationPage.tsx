
import React from 'react';
import AutomationManager from '@/components/Admin/AutomationManager';

const AutomationPage = () => {
  return <AutomationManager />;
};

export default AutomationPage;
