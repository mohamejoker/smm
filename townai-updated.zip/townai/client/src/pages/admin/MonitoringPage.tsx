
import React from 'react';
import SystemMonitoringPanel from '@/components/Admin/SystemMonitoringPanel';

const MonitoringPage = () => {
  return <SystemMonitoringPanel />;
};

export default MonitoringPage;
