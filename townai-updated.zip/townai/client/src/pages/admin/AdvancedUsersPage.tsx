
import React from 'react';
import AdvancedUserManagement from '@/components/Admin/AdvancedUserManagement';

const AdvancedUsersPage = () => {
  return <AdvancedUserManagement />;
};

export default AdvancedUsersPage;
