
import React from 'react';
import AdminSignup from '@/components/Auth/AdminSignup';

const AdminSignupPage = () => {
  return <AdminSignup />;
};

export default AdminSignupPage;
